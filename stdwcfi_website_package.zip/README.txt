STDWCFI SOKOTO WEBSITE SETUP GUIDE
=====================================

This package contains:
- index.html (your website)
- cc.png (logo)
- Instructions for hosting

-------------------------------------
OPTION A: FREE HOSTING ON GITHUB PAGES
-------------------------------------
1. Go to https://github.com and create a free account.
2. Click "+" → "New repository". Name it: stdwcfi-sokoto
3. Upload both files (index.html and cc.png).
4. Click Settings → Pages → Choose branch: "main" and folder: "/root".
5. Click Save — your website will be live at:
   https://<yourusername>.github.io/stdwcfi-sokoto

-------------------------------------
OPTION B: PAID HOSTING WITH CUSTOM DOMAIN
-------------------------------------
1. Buy your domain (stdwcfi.org.ng) from Namecheap, Hostinger, or Whogohost.
2. Login to your hosting control panel (cPanel or File Manager).
3. Go to File Manager → public_html folder.
4. Upload 'index.html' and 'cc.png' here.
5. Visit: https://stdwcfi.org.ng to view your site.

-------------------------------------
HOW TO EDIT YOUR WEBSITE
-------------------------------------
- Open 'index.html' in Notepad, VS Code, or any HTML editor.
- Look for comments like <!-- Edit this section --> to update text or images.
- Save and re-upload the file to update your live site.
